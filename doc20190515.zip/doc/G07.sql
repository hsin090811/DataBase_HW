-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: g07
-- ------------------------------------------------------
-- Server version	8.0.15

/* !40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/* !40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/* !40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/* !40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/* !40103 SET TIME_ZONE='+00:00' */;
/* !40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/* !40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/* !40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/* !40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/* !40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `member` (
  `pName` varchar(20) NOT NULL,
  `pId` varchar(15) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  PRIMARY KEY (`pId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* !40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/* !40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('某A','accountA','accountA'),('某B','accountB','accountB'),('某C','accountC','accountC'),('某D','accountD','accountD'),('某E','accountE','accountE');
/* !40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/* !40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/* !40101 SET SQL_MODE=@OLD_SQL_MODE */;
/* !40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/* !40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/* !40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/* !40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/* !40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/* !40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-12  2:18:54
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.15

/* !40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/* !40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/* !40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/* !40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/* !40103 SET TIME_ZONE='+00:00' */;
/* !40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/* !40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/* !40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/* !40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/* !40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `article` (
  `aId` int(20) NOT NULL AUTO_INCREMENT,
  `pId` varchar(15) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `aTxt` varchar(1000) DEFAULT NULL,
  `aTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`aId`),
  KEY `pId` (`pId`),
  CONSTRAINT `article_ibfk_1` FOREIGN KEY (`pId`) REFERENCES `member` (`pId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/* !40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/* !40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'accountA','我到底是天才還是笨蛋？','一青年向道士求教：「師傅，有人說我是天才，也有人罵我是笨蛋，依你看呢？」\r\n\r\n「你是如何看待自己的？」道士反問，青年一臉茫然。\r\n\r\n「譬如一斤米，在糕餅家眼裡是糕餅；在製酒商眼中又成了酒，在乞丐眼裡，那就是救命的一頓飯。\r\n\r\n不過，米還是那斤米。同樣，你還是你。\r\n\r\n有多大的出息，取決於你怎麼看待自己。」青年豁然開朗。\r\n\r\n感悟：你看待自己的方式，決定了自己的價值，每個人都是有價值的，不要說自己「做不到」。\r\n','2019-05-11 17:48:46'),(2,'accountB','衰老的跡象','這是由一位有自信心的女士寫的。\r\n\r\n有一天，會議結束後，我從旅館出來，開始尋找我的汽車鑰匙，發現它不在我的口袋裡。趕快回會議室裏快速搜尋，卻也了無蹤影。\r\n\r\n突然間，我想到我一定是把它留在車子裡了。\r\n\r\n我的丈夫曾經多次對我大叫，說我把鑰匙留在汽車的鑰匙孔裡了。\r\n\r\n我的想法是，把鑰匙留在鑰匙孔是最不會丟掉它的地方。\r\n\r\n他的想法是，如果把鑰匙留在鑰匙孔的話，汽車將會被偷！\r\n\r\n我立即趕到停車場，得了一個可怕的結論。\r\n\r\n他的想法是對的，因為停車場是空空如也。\r\n\r\n我立刻打電話給警察，告訴他們我現在的位置，汽車的描述，我停放汽車的地方….等等。\r\n\r\n我也承認我把鑰匙留在車子裡，而且汽車被偷了。\r\n\r\n然後，我很為難地打電話給我的丈夫，告訴他：「我把鑰匙留在車裡，而且車子已經被偷了。」\r\n\r\n對方沈默了一陣子，我以為電話已經斷線了，但後來我聽到了他的聲音。\r\n\r\n「白痴」，他喊道，「是我開車送你去旅館的！」\r\n\r\n現在是我沉默的時候了；我很尷尬，同時也很開心。我說：「好吧，那請你來接我吧！」\r\n\r\n他再次大聲喊道：「我會的，等我說服這名警察，讓他相信我並沒有偷走妳的車，我就會去接妳。」\r\n\r\n不要一個人笑。\r\n\r\n發送給其他丈夫或妻子，因為......每天都有很多事情出錯，你不能一直責怪自己。','2019-05-11 17:49:38'),(3,'accountC','致：漸漸老去的我們','我喜歡這段話：\r\n\r\n人，往往在貪欲中失去幸福；在忙碌中失去健康；在懷疑中失去信任；在計較中失去友情。\r\n\r\n人不爭，一身輕鬆；事不比，一路暢通；心不求，一生平靜。\r\n\r\n每個人都有自己的活法，沒必要去複製別人的生活。\r\n\r\n有的人表面風光，暗地裡卻不知流了多少眼淚；有的人看似生活窘迫，實際上卻過得瀟灑快活。\r\n\r\n幸福沒有標準答案，快樂也不止一條道路；收回羡慕別人的目光，反觀自己的內心。\r\n\r\n自己喜歡的日子，就是最好的日子；自己喜歡的活法，就是最好的活法。\r\n\r\n不知不覺中，我們漸漸老了。累了，該歇就歇，身體重要；困了，該睡就睡，別總熬夜；餓了，該吃就吃，別再節省。\r\n\r\n一輩子很短，眨眼就過完，不要把好東西留到最後，省來省去，啥都得不到。\r\n\r\n別和小人計較，別和家人生氣，別和自己過不去，別讓心情不美麗。活一天，就開心一天，過一天，就舒服一天，破事不放心裡，兩耳不聽碎語。\r\n\r\n致：漸漸老去的我們！','2019-05-11 17:52:27'),(4,'accountE','原諒的力量','在非洲有一個部落，當某人做了錯事，村民會把他帶到村莊的中心，然後大家一起圍繞著他長達兩天。\r\n\r\n這兩天，他們非但沒有指責他，還會不停的贊揚那人曾經做過的好事。\r\n\r\n這個部落認為，每一個人來到這世上時都是好的，我們每一個人都渴望安全、和平、愛和幸福。\r\n\r\n但有時候，在追求這些東西的同時，人們會犯錯誤。\r\n\r\n這些部落的人把錯誤的行為視為對方的呼救，他們團結起來扶持並幫助他，幫他找回最初的本性，直到他完全記得他已暫時遺忘的本性，就是「我是好人」。','2019-05-11 17:53:30'),(5,'accountA','心態影響行為，性格決定命運','父親有兩個兒子，雖說是一對孿生兄弟，性格卻大相逕庭。\r\n\r\n老大過分悲觀，老二卻特別樂觀。\r\n\r\n父親一直都想做點什麼改變他們。\r\n\r\n有一天午餐後，他買了許多新玩具給老大，卻給了老二好多破舊的玩具，有的還是壞的。讓他們各自回自己房間玩。\r\n\r\n幾個小時後，父親先到老大的房間，卻看到老大正在哭，便問老大：「給你買了這麼多新的玩具，你為什麼不玩呢？」\r\n\r\n老大泣不成聲地說，「如果我玩了，它們就會變成舊玩具，也許還會壞掉的。」\r\n\r\n父親搖了搖頭，很失望。\r\n\r\n等他來到老二的房間，卻意外地發現老二正在興奮地敲敲打打。「爸爸，我跟你講哦，我馬上就能把這個玩具修好啦，我很厲害吧？」\r\n\r\n樂觀的人在困難中看到希望，悲觀的人在希望中看到困難。\r\n\r\n心態影響行為，行為形成習慣，習慣塑造性格，性格決定命運。\r\n\r\n人生一場，比的就是心態。','2019-05-11 17:55:36');
/* !40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/* !40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/* !40101 SET SQL_MODE=@OLD_SQL_MODE */;
/* !40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/* !40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/* !40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/* !40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/* !40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/* !40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-12  2:18:55
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.15

/* !40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/* !40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/* !40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/* !40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/* !40103 SET TIME_ZONE='+00:00' */;
/* !40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/* !40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/* !40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/* !40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/* !40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `message` (
  `mNum` int(15) NOT NULL AUTO_INCREMENT,
  `aId` int(20) DEFAULT NULL,
  `pId` varchar(15) DEFAULT NULL,
  `mTxt` varchar(500) DEFAULT NULL,
  `mTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mNum`),
  KEY `pId` (`pId`),
  KEY `aId` (`aId`),
  CONSTRAINT `message_ibfk_1` FOREIGN KEY (`pId`) REFERENCES `member` (`pId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `message_ibfk_2` FOREIGN KEY (`aId`) REFERENCES `article` (`aId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/* !40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/* !40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,1,'accountA','阿...原來是這樣啊','2019-05-11 17:56:43'),(2,1,'accountB','真的!!','2019-05-11 17:57:17'),(3,3,'accountB','認同!!','2019-05-11 17:57:31'),(4,4,'accountB','哈哈好特別喔','2019-05-11 17:58:01'),(5,4,'accountD','哇','2019-05-11 17:58:24'),(6,5,'accountD','認同欸','2019-05-11 17:58:38'),(7,2,'accountD','讚','2019-05-11 17:58:54'),(8,1,'accountD','不錯喔','2019-05-11 17:59:08'),(9,3,'accountD','哈哈 真的別和自己過不去','2019-05-11 17:59:43'),(10,5,'accountC','哈哈','2019-05-11 18:00:16'),(11,4,'accountC','好酷喔','2019-05-11 18:00:27'),(12,1,'accountC','原來','2019-05-11 18:00:41'),(13,3,'accountC','讚喔','2019-05-11 18:00:56');
/* !40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;
/* !40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/* !40101 SET SQL_MODE=@OLD_SQL_MODE */;
/* !40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/* !40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/* !40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/* !40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/* !40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/* !40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-12  2:18:55
