const db = require('../util/database');

module.exports = class Member {
  constructor(pName, pId, pwd) {
    this.pName = pName;
    this.pId = pId;
    this.pwd = pwd;
  }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.price);
    return db.execute(
      'INSERT INTO member (pName, pId, pwd) VALUES (?, ?, ?)',
      [req.body.pName, req.body.pId, req.body.pwd]
    );
  }
// READ
  static pIdCk(req, res) {
    return db.execute(
      'SELECT IFNULL(COUNT(pId),0) as count FROM member where pId = ?', [req.body.pId]
    );
  }

  static fetchAll() {
    return db.execute('SELECT * FROM member');
  }

  static fetchOne(req,res) {
    return db.execute('SELECT * FROM member WHERE pId = ?',[req.query.pId]);
  }

  static findById(req,res) {
    return db.execute('SELECT IFNULL(COUNT(pId),0) as count FROM member where pId = ? AND pwd = ?', [req.body.pId,req.body.pwd]);
  }

  //DELETE
  static delete(req,res){
    return db.execute('DELETE FROM member WHERE pId = ?', [req.query.pId]);
  }

  //UPDATE
  static update(req,res){
    return db.execute('UPDATE member SET pName = ? , pId = ? , pwd = ?  WHERE pId = ?', [req.body.pName, req.body.pId, req.body.pwd, req.query.pId]);
  }
};