const db = require('../util/database');

module.exports = class articleMes {
    constructor(aId, pId, title, aTxt, aTime, pName) {
        this.aId = aId;
        this.pId = pId;
        this.title = title;
        this.aTxt = aTxt;
        this.aTime = aTime;
        this.pName = pName;
    }

    // READ
    static findById(id) {
        return db.execute('SELECT aId,title,aTxt,aTime,pName FROM article LEFT JOIN member ON article.pId = member.pId where aId = ?', [id]);
    }
}