const db = require('../util/database');

module.exports = class articleMes {
    constructor(mNum, aId, pId, mTxt, mTime) {
        this.mNum = mNum;
        this.aId = aId;
        this.pId = pId;
        this.mTxt = mTxt;
        this.mTime = mTime;
    }

    // READ
    static findById(num) {
        return db.execute('SELECT * FROM message where mNum = ?', [num]);
    }

    // UPDATE
    static updateById(req, res) {
      const mNum = req.body.edit;
      const demoMessage = req.body.demoMessage;
      console.log('model:updateById()', mNum, demoMessage)
      return db.execute(
        'UPDATE message SET mTxt = ? WHERE mNum = ?', [demoMessage, mNum]
      );
    }
}