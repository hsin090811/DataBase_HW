const db = require('../util/database');

module.exports = class article {
    constructor(aId, pId, title, aTxt, aTime) {
        this.aId = aId;
        this.pId = pId;
        this.title = title;
        this.aTxt = aTxt;
        this.aTime = aTime;
    }

    // READ
    static fetchAll() {
        return db.execute('SELECT * FROM article');
    }

    static fetchOne(req, res) {
        return db.execute('SELECT * FROM article WHERE aId = ?', [req.query.aId]);
    }

    static getarticle() {
        return db.execute('SELECT COUNT(*) as count FROM article');
    }

    static aIdck(req, res) {
        return db.execute(
            'SELECT IFNULL(COUNT(aId),0) as count FROM article where aId = ?', [req.body.aId]
        );
    }

    static pIdck(req, res) {
        return db.execute(
            'SELECT IFNULL(COUNT(pId),0) as count FROM member where pId = ?', [req.body.pId]
        );
    }

    static delete(req, res) {
        return db.execute('DELETE FROM article WHERE aId = ?', [req.query.aId]);
    }

    static addT(req, res) {
        if(req.body.aId == '') req.body.aId = null;
        return db.execute(
            'INSERT INTO article (aId, pId, title, aTxt, aTime) VALUES (?, ?, ?, ?, ?)',
            [req.body.aId, req.body.pId, req.body.title, req.body.aTxt, req.body.aTime]
        );
    }

    static add(req, res) {
        if(req.body.aId == '') req.body.aId = null;
        return db.execute(
            'INSERT INTO article (aId, pId, title, aTxt) VALUES (?, ?, ?, ?)',
            [req.body.aId, req.body.pId, req.body.title, req.body.aTxt]
        );
    }


    static updateT(req, res) {
        return db.execute('UPDATE article SET aId = ? , pId = ? , title = ? , aTxt = ? , aTime = ? WHERE aId = ?', [req.body.aId, req.body.pId, req.body.title, req.body.aTxt, req.body.aTime, req.query.aId]);
    }

    static update(req, res) {
        return db.execute('UPDATE article SET aId = ? , pId = ? , title = ? , aTxt = ? WHERE aId = ?', [req.body.aId, req.body.pId, req.body.title, req.body.aTxt, req.query.aId]);
    }
}