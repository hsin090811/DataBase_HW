const db = require('../util/database');

module.exports = class articleMes {
    constructor(mNum, aId, pId, mTxt, mTime) {
        this.mNum = mNum;
        this.aId = aId;
        this.pId = pId;
        this.mTxt = mTxt;
        this.mTime = mTime;
    }

    // READ
    static findById(id) {
        return db.execute('SELECT * FROM message where aId = ?', [id]);
    }

    static getCount(id){
        return db.execute('SELECT COUNT(*) as count FROM message where aId = ?', [id]);
    }

    static fetchAll() {
        return db.execute('SELECT * FROM message ORDER BY aId');
    }

    static fetchOne(req, res) {
        return db.execute('SELECT * FROM message WHERE mNum = ?', [req.query.mNum]);
    }

    static mNumck(req, res) {
        return db.execute(
            'SELECT IFNULL(COUNT(mNum),0) as count FROM message where mNum = ?', [req.body.mNum]
        );
    }

    static aIdck(req, res) {
        return db.execute(
            'SELECT IFNULL(COUNT(aId),0) as count FROM article where aId = ?', [req.body.aId]
        );
    }

    static pIdck(req, res) {
        return db.execute(
            'SELECT IFNULL(COUNT(pId),0) as count FROM member where pId = ?', [req.body.pId]
        );
    }

    static delete(req, res) {
        return db.execute('DELETE FROM message WHERE mNum = ?', [req.query.mNum]);
    }

    static addT(req, res) {
        if(req.body.mNum == '') req.body.mNum = null;
        return db.execute(
            'INSERT INTO message (mNum, aId, pId, mTxt, mTime) VALUES (?, ?, ?, ?, ?)',
            [req.body.mNum, req.body.aId, req.body.pId, req.body.mTxt, req.body.mTime]
        );
    }

    static add(req, res) {
        if(req.body.mNum == '') req.body.mNum = null;
        return db.execute(
            'INSERT INTO message (mNum, aId, pId, mTxt) VALUES (?, ?, ?, ?)',
            [req.body.mNum, req.body.aId, req.body.pId, req.body.mTxt]
        );
    }


    static updateT(req, res) {
        return db.execute('UPDATE message SET mNum = ? , aId = ? , pId = ? , mTxt = ? , mTime = ? WHERE mNum = ?', [req.body.mNum, req.body.aId, req.body.pId, req.body.mTxt, req.body.mTime, req.query.mNum]);
    }

    static update(req, res) {
        return db.execute('UPDATE message SET mNum = ? , aId = ? , pId = ? , mTxt = ? WHERE mNum = ?', [req.body.mNum, req.body.aId, req.body.pId, req.body.mTxt, req.query.mNum]);
    }
}