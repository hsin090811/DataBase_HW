const db = require('../util/database');  //連資料庫

module.exports = class mesPost {
  constructor(aId, pId, mTxt, mTime) {
    this.aId = aId;
    this.pId = pId;
    this.mTxt = mTxt;
    this.mTime = mTime;
  }

    static add(req, res) {
    //   console.log('add():', req.body.aId);
      return db.execute(
          'INSERT INTO message (aId, pId, mTxt) VALUES ( ?, ?, ?)',
          [req.body.aId, req.cookies.pId, req.body.demoMessage]
      );
    }


  // DELETE
    static delete(req, res) {
        // console.log(req.query.delete);
        return db.execute(
          'DELETE FROM message WHERE mNum = ?', [req.query.delete]
        );
    }
};