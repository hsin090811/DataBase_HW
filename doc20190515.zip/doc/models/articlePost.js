const db = require('../util/database');  //連資料庫

module.exports = class Post {
  constructor(aId, pId, title, aTxt, aTime) {
    this.aId = aId;
    this.pId = pId;
    this.title = title;
    this.aTxt = aTxt;
    this.aTime = aTime;
}

  // 發文章 req.body.name代表在views\articlePost.ejs中body中的表單name='name',req.body.message也是
  static add(req, res) {
    console.log('add():', req.body.name, req.body.message);
    return db.execute(
      'INSERT INTO article (pId, title, aTxt) VALUES (?, ?, ?)',
      [req.cookies.pId, req.body.name, req.body.message]
    );
  }

};