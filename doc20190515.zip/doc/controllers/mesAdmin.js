const moment = require('moment');
const Message = require('../models/mesAll');


exports.getmsgTb = async (req, res, next) => {
    const getmessage = Message.fetchAll()
        .then(([rows]) => {
            for (let p of rows) {
                p.mTime = moment(p.mTime).format('YYYY-MM-DD HH:mm:ss');
            }
            res.render('admin/msgTb', {
                title: 'Message Tables',
                data: rows
            });
        })
        .catch(err => console.log(err));
};

exports.msgUpdate = async (req, res, next) => {
    const msgsearch = await Message.fetchOne(req, res)
        .then(([rows]) => {
            rows[0].mTime = moment(rows[0].mTime).format('YYYY-MM-DD HH:mm:ss');
            res.render('admin/msgUpdate', {
                title: 'Update Message',
                data: rows
            });
        })
        .catch(err => console.log(err));
};

exports.adupM = async (req, res, next) => {
    
    let aIdcheck;
    let pIdcheck;
    
    const aIdUck = await Message.aIdck(req, res)
        .then(([rows]) => {
            aIdcheck = rows[0].count;
        })
        .catch(err => console.log(err));
    const pIdUck = await Message.pIdck(req, res)
        .then(([rows]) => {
            pIdcheck = rows[0].count;
        })
        .catch(err => console.log(err));
    if (req.query.mNum == req.body.mNum) {
        if (aIdcheck == '1' && pIdcheck == '1') {
            if (req.body.mTime == '') {
                Message.update(req, res)
                    .then(([rows]) => {
                        res.redirect('/msgTb');
                    })
                    .catch(err => console.log(err));
            }
            else {
                req.body.mTime = (req.body.mTime).replace('T', ' ') + ':00';
                Message.updateT(req, res)
                    .then(([rows]) => {
                        res.redirect('/msgTb');
                    })
                    .catch(err => console.log(err));
            }
        }
        else {
            res.redirect('/msgTb');
        }
    }
    else {
        let mNumcheck;
        const mNumUck = await Message.mNumck(req, res)
        .then(([rows]) => {
            mNumcheck = rows[0].count;
        })
        .catch(err => console.log(err));

        if (mNumcheck == '0' && aIdcheck == '1' && pIdcheck == '1') {
            if (req.body.mTime == '') {
                Message.update(req, res)
                    .then(([rows]) => {
                        res.redirect('/msgTb');
                    })
                    .catch(err => console.log(err));
            }
            else {
                req.body.mTime = (req.body.mTime).replace('T', ' ') + ':00';
                Message.updateT(req, res)
                    .then(([rows]) => {
                        res.redirect('/msgTb');
                    })
                    .catch(err => console.log(err));
            }
        }
        else {
            res.redirect('/msgTb');
        }
    }
};

exports.addelM = async (req, res, next) => {
    Message.delete(req, res)
        .then(([rows]) => {
            res.redirect('/msgTb');
        })
        .catch(err => console.log(err));
};


exports.adaddM = async (req, res, next) => {
    let mNumcheck;
    let aIdcheck;
    let pIdcheck;

    const mNumUck = await Message.mNumck(req, res)
        .then(([rows]) => {
            mNumcheck = rows[0].count;
        })
        .catch(err => console.log(err));
    const aIdUck = await Message.aIdck(req, res)
        .then(([rows]) => {
            aIdcheck = rows[0].count;
        })
        .catch(err => console.log(err));
    const pIdUck = await Message.pIdck(req, res)
        .then(([rows]) => {
            pIdcheck = rows[0].count;
        })
        .catch(err => console.log(err));

    if (mNumcheck == '0' && aIdcheck == '1' && pIdcheck == '1') {
        if (req.body.mTime != '') {
            req.body.mTime = (req.body.mTime).replace('T', ' ') + ':00';
            Message.addT(req, res)
                .then(([rows]) => {
                    res.redirect('/msgTb');
                })
                .catch(err => console.log(err));
        }
        else {
            Message.add(req, res)
                .then(([rows]) => {
                    res.redirect('/msgTb');
                })
                .catch(err => console.log(err));
        }
    }
    else {
        res.redirect('/msgTb');
    }
};