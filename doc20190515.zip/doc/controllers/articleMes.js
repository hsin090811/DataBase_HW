const moment = require('moment');

const MesAll = require('../models/mesAll');
const ArticleMes = require('../models/articleMes');
const MesPost = require('../models/mesPost');

exports.getArticleMes = async (req, res, next) => {

  let article;
  let mes;
  let mesCounts;

  try {
    
    const getArticle = await ArticleMes.findById(req.query.aId)
      .then(([rows]) => {
        console.log(rows);
        for (let p of rows) {
          p.aTime = moment(p.aTime).format('YYYY-MM-DD HH:mm:ss');
        }
        article = rows[0];
      })

    const getMes = await MesAll.findById(req.query.aId)
      .then(([rows]) => {
        for (let p of rows) {
          p.mTime = moment(p.mTime).format('YYYY-MM-DD HH:mm:ss');
        }
        mes = rows;
      })

    const getMesCounts = await MesAll.getCount(req.query.aId)
      .then(([rows]) => {
        mesCounts = rows[0].count;
      })

    let data = {
      article: article,
      mes: mes,
      mesCounts: mesCounts
    }

    console.log(JSON.stringify(data));
    //res.send(JSON.stringify(data));

    res.render('client/articleMes', {
      title: 'Article Text',
      article: article,
      mes: mes,
      mesCounts: mesCounts,
      thepId: req.cookies.pId
    });

  } catch (err) {
    console.log(err);
  };

};

exports.getMesPost = (req, res, next) => {
  // console.log(req);

  MesPost.add(req, res)
      .then(([rows]) => {
          res.redirect('/articleMes?aId='+ req.body.aId);
      })
  
      .catch(err => console.log(err));
};

exports.getMesDelete = (req, res, next) => {
    // console.log("delete:",req.query.delete,req.query.aId);
    MesPost.delete(req, res)
        .then(([rows]) => {
            res.redirect('/articleMes?aId=' + req.query.aId);
        })
        .catch(err => console.log(err));
};