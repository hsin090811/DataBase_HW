const moment = require('moment');

const MesEdit = require('../models/mesEdit');
const ArticleMes = require('../models/articleMes'); 

/* READ *****************************/


exports.getMesEdit = async (req, res, next) => {

    let mes;
    let article;

    const getMes = await MesEdit.findById(req.query.edit)
      .then(([rows]) => {
        for (let p of rows) {
          p.mTime = moment(p.mTime).format('YYYY-MM-DD HH:mm:ss');
        }
        mes = rows[0];
    })

    const getArticle = await ArticleMes.findById(req.query.aId)
      .then(([rows]) => {
        console.log(rows);
        for (let p of rows) {
          p.aTime = moment(p.aTime).format('YYYY-MM-DD HH:mm:ss');
        }
        article = rows[0];
    })  

    let data = {
        mes: mes,
        article: article
    }

    console.log('post: ', JSON.stringify(data));
    
    res.render('client/mesEdit', {
        title: 'Message Edit',
        mes: mes,
        article: article,
        thepId: req.cookies.pId
   });

};


exports.getMesUpdate = (req, res, next) => {

    MesEdit.updateById(req, res)
        .then(([rows]) => {
            res.redirect('/articleMes?aId='+ req.body.aId);
        })
        .catch(err => console.log(err));
};
