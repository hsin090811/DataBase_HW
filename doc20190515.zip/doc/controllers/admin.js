const moment = require('moment');

exports.adminLog = (req, res, next) => {
    res.render('admin/dashboard');
  };