const moment = require('moment');
const Member = require('../models/member');

//client
/* READ *****************************/

exports.addMem = async (req, res, next) => {
  let result;

  const Memck = await Member.pIdCk(req, res)
    .then(([rows]) => {
      result = rows[0].count;
      if (result == '0') {
        Member.add(req, res)
          .then(([rows]) => {
            res.redirect('/?reg="t"');
          })
          .catch(err => console.log(err));
      }
      else if (result == '1') {
        res.redirect('/register?reg="f"');
      }
      else {
        res.redirect('/');
      }
    })
};

exports.showReg = (req, res, next) => {
  res.render('client/register');
};

exports.showLog = (req, res, next) => {
  res.render('client/log');
};



exports.getPwd = async (req, res, next) => {
  let result;

  const logCk = await Member.findById(req, res)
    .then(([rows]) => {


      result = rows[0].count;
      console.log(result);

      if (result == '1') {
        res.cookie('pId', req.body.pId);
        res.redirect('/article');
      }
      else if (result == '0') {
        res.redirect('/?log="f"');
      }
      else {
        console.log("error")
        res.redirect('/?log="r"');
      }
    })
    .catch(err => console.log(err));
};

exports.logOut = (req, res, next) => {
  res.cookie('pId', { expires: Date.now() });
  res.redirect('/');
};

//admin
exports.getmemTb = async (req, res, next) => {
  const getmem = await Member.fetchAll(req, res)
    .then(([rows]) => {
      res.render('admin/memTb', {
        title: 'Member Tables',
        data: rows
      });
    })
    .catch(err => console.log(err));
};

exports.delMem = (req, res, next) => {
  Member.delete(req, res)
    .then(([rows]) => {
      res.redirect('/memTb');
    })
    .catch(err => console.log(err));
};

exports.memUpdate = async (req, res, next) => {
  const Memsearch = await Member.fetchOne(req, res)
    .then(([rows]) => {
      res.render('admin/memUpdate', {
        title: 'Update Member',
        data: rows
      });
    })
    .catch(err => console.log(err));
};

exports.adupM = async (req, res, next) => {
  if (req.query.pId == req.body.pId) {
    Member.update(req, res)
      .then(([rows]) => {
        res.redirect('/memTb');
      })
      .catch(err => console.log(err));
  }
  else {
    const MemUck = await Member.pIdCk(req, res)
      .then(([rows]) => {
        if (rows[0].count == '0') {
          Member.update(req, res)
            .then(([rows]) => {
              res.redirect('/memTb');
            })
            .catch(err => console.log(err));
        }
        else {
          res.redirect('/memTb');
        }
      })
      .catch(err => console.log(err));
  }
};

exports.adaddM = async (req, res, next) => {
  const Memck = await Member.pIdCk(req, res)
    .then(([rows]) => {
      result = rows[0].count;
      console.log(result);
      if (result == '0') {
        Member.add(req, res)
          .then(([rows]) => {
            res.redirect('/memTb');
          })
          .catch(err => console.log(err));
      }
      else {
        res.redirect('/memTb');
      }
    })
    .catch(err => console.log(err));
};