const moment = require('moment');

const Post = require('../models/articlePost');   //跳到../models/post去寫SQL指令
//const Category = require('../models/category');

/* READ *****************************/

exports.getPosts = (req, res, next) => {
            res.render('client/articlePost', {
                title: 'Post List',
                thepId: req.cookies.pId
            });
       
};

exports.postAddPost = (req, res, next) => {
    //console.log(req);
    Post.add(req, res)
        .then(([rows]) => {
            console.log(req);
            res.redirect('/article');
        })
    
        .catch(err => console.log(err));
};