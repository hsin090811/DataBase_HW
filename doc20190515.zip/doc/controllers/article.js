const moment = require('moment');

const Article = require('../models/article'); //跳到../models/category去寫SQL指令

//client
exports.getarticle = async (req, res, next) => {


  var categories;

  const getCategories = Article.fetchAll()
    .then(([rows]) => {
      for (let p of rows) {
        p.aTime = moment(p.aTime).format('YYYY-MM-DD HH:mm:ss');
      }
      categories = rows;

      console.log('findCategories(): ', JSON.stringify(rows));
      res.render('client/article', {
        title: 'Article',
        data: categories,
        thepId: req.cookies.pId
      });
    })


    .catch(err => console.log(err));
};

//admin
exports.getartTb = async (req, res, next) => {
  const getarticle = Article.fetchAll()
    .then(([rows]) => {
      for (let p of rows) {
        p.aTime = moment(p.aTime).format('YYYY-MM-DD HH:mm:ss');
      }
      res.render('admin/artTb', {
        title: 'Article Tables',
        data: rows
      });
    })
    .catch(err => console.log(err));
};

exports.artUpdate = async (req, res, next) => {
  const artsearch = await Article.fetchOne(req, res)
    .then(([rows]) => {
      rows[0].aTime = moment(rows[0].aTime).format('YYYY-MM-DD HH:mm:ss');
      res.render('admin/artUpdate', {
        title: 'Update Article',
        data: rows
      });
    })
    .catch(err => console.log(err));
};

exports.adupA = async (req, res, next) => {
  let aIdcheck;
  let pIdcheck;

  const pIdUck = await Article.pIdck(req, res)
    .then(([rows]) => {
      pIdcheck = rows[0].count;
    })
    .catch(err => console.log(err));

  if (req.query.aId == req.body.aId) {
    if (pIdcheck == '1') {
      if (req.body.aTime == '') {
        Article.update(req, res)
          .then(([rows]) => {
            res.redirect('/artTb');
          })
          .catch(err => console.log(err));
      }
      else {
        req.body.aTime = (req.body.aTime).replace('T', ' ') + ':00';
        Article.updateT(req, res)
          .then(([rows]) => {
            res.redirect('/artTb');
          })
          .catch(err => console.log(err));
      }
    }
    else {
      res.redirect('/artTb');
    }
  }
  else {
    const aIdUck = await Article.aIdck(req, res)
      .then(([rows]) => {
        aIdcheck = rows[0].count;
      })
      .catch(err => console.log(err));
    if (aIdcheck == '0' && pIdcheck == '1') {
      if (req.body.aTime == '') {
        Article.update(req, res)
          .then(([rows]) => {
            res.redirect('/artTb');
          })
          .catch(err => console.log(err));
      }
      else {
        req.body.aTime = (req.body.aTime).replace('T', ' ') + ':00';
        Article.updateT(req, res)
          .then(([rows]) => {
            res.redirect('/artTb');
          })
          .catch(err => console.log(err));
      }
    }
    else {
      res.redirect('/artTb');
    }
  }
};

exports.addelA = async (req, res, next) => {
  Article.delete(req, res)
    .then(([rows]) => {
      res.redirect('/artTb');
    })
    .catch(err => console.log(err));
}

//Insert
exports.adaddA = async (req, res, next) => {
  let aIdcheck;
  let pIdcheck;

  const aIdck = await Article.aIdck(req, res)
    .then(([rows]) => {
      aIdcheck = rows[0].count;
    })
    .catch(err => console.log(err));
  const pIdck = await Article.pIdck(req, res)
    .then(([rows]) => {
      pIdcheck = rows[0].count;
    })
    .catch(err => console.log(err));
  if (aIdcheck == '0' && pIdcheck == '1') {
    if (req.body.aTime != '') {
      req.body.aTime = (req.body.aTime).replace('T', ' ') + ':00';
      Article.addT(req, res)
        .then(([rows]) => {
          res.redirect('/artTb');
        })
        .catch(err => console.log(err));
    }
    else {
      Article.add(req, res)
        .then(([rows]) => {
          res.redirect('/artTb');
        })
        .catch(err => console.log(err));
    }
  }
  else {
    res.redirect('/artTb');
  }
};