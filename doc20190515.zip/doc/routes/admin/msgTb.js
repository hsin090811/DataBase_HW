var express = require('express');
var router = express.Router();

const msgTbController = require('../../controllers/mesAdmin');

router.get('/', msgTbController.getmsgTb);
router.get('/delete', msgTbController.addelM);
router.post('/add', msgTbController.adaddM);

module.exports = router;