var express = require('express');
var router = express.Router();

const artTbController = require('../../controllers/article');

router.get('/', artTbController.getartTb);
router.get('/delete', artTbController.addelA);
router.post('/add', artTbController.adaddA);

module.exports = router;