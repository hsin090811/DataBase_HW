var express = require('express');
var router = express.Router();

const msgUController = require('../../controllers/mesAdmin');

router.get('/', msgUController.msgUpdate);
router.post('/do', msgUController.adupM);

module.exports = router;