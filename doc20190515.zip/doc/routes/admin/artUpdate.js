var express = require('express');
var router = express.Router();

const artUController = require('../../controllers/article');

router.get('/', artUController.artUpdate);
router.post('/do', artUController.adupA);

module.exports = router;