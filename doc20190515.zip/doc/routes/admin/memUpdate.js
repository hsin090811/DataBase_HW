var express = require('express');
var router = express.Router();

const memUController = require('../../controllers/member');

router.get('/', memUController.memUpdate);
router.post('/do', memUController.adupM);

module.exports = router;