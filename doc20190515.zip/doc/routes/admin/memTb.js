var express = require('express');
var router = express.Router();

const memTbController = require('../../controllers/member');

router.get('/', memTbController.getmemTb);
router.get('/delete', memTbController.delMem);
router.post('/add', memTbController.adaddM);

module.exports = router;