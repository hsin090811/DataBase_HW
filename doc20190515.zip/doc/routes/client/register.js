var express = require('express');
var router = express.Router();

const regController = require('../../controllers/member');

router.get('/', regController.showReg);
router.post('/add', regController.addMem);

module.exports = router;