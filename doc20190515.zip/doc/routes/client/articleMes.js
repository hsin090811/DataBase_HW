var express = require('express');
var router = express.Router();

const articleMesController = require('../../controllers/articleMes');

router.get('/', articleMesController.getArticleMes);
router.post('/mesPost', articleMesController.getMesPost);
router.get('/mesDelete', articleMesController.getMesDelete);

module.exports = router;