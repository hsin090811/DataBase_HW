var express = require('express');
var router = express.Router();

const articleController = require('../../controllers/article');//
/* GET home page. */
router.get('/', articleController.getarticle);


module.exports = router;
