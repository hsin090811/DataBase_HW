var express = require('express');
var router = express.Router();

const postController = require('../../controllers/articlePost');//控制post的地方

router.get('/', postController.getPosts);//在controllers/post.js裡有這兩個指令
router.post('/add', postController.postAddPost);



module.exports = router;