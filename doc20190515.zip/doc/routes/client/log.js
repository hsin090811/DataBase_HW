var express = require('express');
var router = express.Router();

const logController = require('../../controllers/member');

router.get('/', logController.showLog);
router.post('/login', logController.getPwd);
router.get('/logout', logController.logOut);

module.exports = router;