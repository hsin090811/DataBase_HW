var express = require('express');
var router = express.Router();

const mesEditController = require('../../controllers/mesEdit');//控制post的地方

router.get('/', mesEditController.getMesEdit);
router.post('/Update', mesEditController.getMesUpdate);


module.exports = router;