var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');



//admin
const adminRouter = require('./routes/admin/dashboard');
const memTbRouter = require('./routes/admin/memTb');
const memURouter = require('./routes/admin/memUpdate');
const artTbRouter = require('./routes/admin/artTb');
const artURouter = require('./routes/admin/artUpdate');
const msgTbRouter = require('./routes/admin/msgTb');
const msgURouter = require('./routes/admin/msgUpdate');
//client
const logRouter = require('./routes/client/log');
const regRouter = require('./routes/client/register');
const articlePostRouter = require('./routes/client/articlePost');
const articleRouter = require('./routes/client/article');
const articleMesRouter = require('./routes/client/articleMes');
const MesEditRouter = require('./routes/client/mesEdit');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

//app.use('/index', rootRouter);
//admin
app.use('/dashboard', adminRouter);
app.use('/memTb', memTbRouter);
app.use('/memUpdate', memURouter);
app.use('/artTb', artTbRouter);
app.use('/artUpdate', artURouter);
app.use('/msgTb', msgTbRouter);
app.use('/msgUpdate', msgURouter);
// app.use('/post', postRouter);
//client
app.use('/', logRouter);
app.use('/log', logRouter);
app.use('/register', regRouter);
app.use('/articlePost', articlePostRouter); //跳到routes的post.js
app.use('/article', articleRouter);
app.use('/articleMes', articleMesRouter);
app.use('/mesEdit', MesEditRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});

module.exports = app;